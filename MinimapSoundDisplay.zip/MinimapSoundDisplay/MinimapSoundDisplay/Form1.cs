﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace MinimapSoundDisplay
{
    public partial class Form1 : Form
    {

        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        public static extern IntPtr SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int Y, int cx, int cy, int wFlags);

        public static void Move(IntPtr handle, int x, int y)
        {
            const short SWP_NOMOVE = 0X2;
            const short SWP_NOSIZE = 1;
            const short SWP_NOZORDER = 0X4;
            const int SWP_SHOWWINDOW = 0x0040;

            Process[] processes = Process.GetProcesses(".");
            foreach (var process in processes)
            {
                var form = FromHandle(handle);
                if (handle != IntPtr.Zero)
                {
                    SetWindowPos(handle, 0, 0, 0, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_SHOWWINDOW);
                }

                SetWindowPos(handle, 0, x, y, form.Bounds.Width, form.Bounds.Height, SWP_NOZORDER | SWP_SHOWWINDOW);
            }
        }

        public Form1()
        {
            InitializeComponent();
            Form1_Load();
        }


        private void Form1_Load()
        {
            // Loads Form2 when launching this form
            // The (this) makes form2 launch and stay on top of form1
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Form2 xhair = new Form2();
            xhair.StartPosition = FormStartPosition.CenterScreen;
            xhair.Show(this);
            Show();
            Form3 howToUseDialog = new Form3();
            howToUseDialog.StartPosition = FormStartPosition.CenterScreen;
            resizeWindow();
            howToUseDialog.ShowDialog();
        }

        private void dust2ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_dust2_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void mirageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_mirage_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void infernoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_inferno_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void cacheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_cache_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void overpassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_overpass_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void trainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_train_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // cobblestone
        private void nukeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_cbble_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void nukeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            pictureBox.Image = Properties.Resources.de_nuke_radar;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //-----------------------------------

        private void pictureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = null;
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg";
            if (file.ShowDialog() == DialogResult.OK)
            {
                path = file.FileName;
            }

            if (path.Equals(null)) return;

            pictureBox.Image = null;
            Bitmap bitmap = new Bitmap(path);
            pictureBox.Image = bitmap;
            bool r = resizeWindow();
            if (!r) MessageBox.Show("The image selected had too big resolution to handle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool resizeWindow()
        {
            if (pictureBox.Image == null)
            {
                Width = 1000;
                Height = 1000;
                return true;
            }
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;

            int picWidth = pictureBox.Image.Size.Width;
            int picHeight = pictureBox.Image.Size.Height;

            if (picWidth > screenWidth || picHeight > screenHeight) return false;

            Width = picWidth;
            Height = picHeight + 70;
            return true;
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {

        }

        // reset menu strip
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}
