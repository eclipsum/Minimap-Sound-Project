﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MinimapSoundDisplay
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            TransparencyKey = BackColor;
            FormBorderStyle = FormBorderStyle.None;
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            // New Ellpise
            Graphics g = e.Graphics;
            Pen black = new Pen(Color.LightGray);
            g.FillEllipse(Brushes.Aqua, 173, 10, 16, 16);
            g.DrawEllipse(black, 0, 0, 360, 360);
            g.FillEllipse(Brushes.White, 180, 180, 4, 4);
            g.Dispose();

        }

        // Disables x button, could accidentaly be clicked
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)

        {
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Left)
            {
                Capture = false;
                Message msg = Message.Create(Handle, 0XA1, new IntPtr(2), IntPtr.Zero);
                WndProc(ref msg);
            }
        }

        /* This is just a temporary solution to a very frustrating problem.
         * I want to create a draggable bitmap, shape, or picturebox that is
         * slight opaque, however over 10 hours I could make literally no progress
         * doing this. It would look prettier and would make the program feel better
         * Thanks if you manage to do it, I think it may just not possible in VS
         */
    }
}
