Hi developers,

This program is a mess. As said in the video, it's my first large project ever,
and since I was self-taught and only wanted to learn how to, and not about the
conventions that should be used for multi-person development, you'll have a horrible
time trying to edit this I'm guessing. I'm be paying special attention to comments
on this video, so if you have a question on where something is stored just ask there.
EXE : C:\Users\Pampperin\Desktop\Videos\Projects\Current Project\MinimapSoundDisplay\MinimapSoundDisplay\bin\Debug
Resources : C:\Users\Pampperin\Desktop\Videos\Projects\Current Project\MinimapSoundDisplay\MinimapSoundDisplay\Resources

The DDS files for minimaps were from the actual game, I converted them to PNGs so I could use them straight in the bitmap.
I kept them here if someone somehow wants to use it.

Sorry for the messy stuff :P I don't clean up well (it's why I don't show my face ;P)

Dinoswarleafs